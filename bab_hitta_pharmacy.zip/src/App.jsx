// Import necessary hooks and icons
import { useState, useEffect } from "react";
import { Menu, X, Copy } from "lucide-react";
import { motion } from "framer-motion";

// -- Full React component from canvas --
export default function BabHittaPharmacyWebsite() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState(null);
  const [applauseCount, setApplauseCount] = useState(0);
  const [hasApplauded, setHasApplauded] = useState(false);

  useEffect(() => {
    const applauded = localStorage.getItem("hasApplauded");
    if (applauded === "true") {
      setHasApplauded(true);
    }
  }, []);

  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  const handleCopy = (text, index) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 1500);
    });
  };

  const handleApplause = () => {
    if (!hasApplauded) {
      setApplauseCount(applauseCount + 1);
      setHasApplauded(true);
      localStorage.setItem("hasApplauded", "true");
    }
  };

  const branchData = [
    { name: "Bab Hitta Deir-Ghbar 1", phone: "06 592 9474", mapUrl: "https://maps.app.goo.gl/AjxsKhUZ95qF6T4C7", hours: "8am - 2am" },
    { name: "Bab Hitta 7thCircle", phone: "06 585 1850", mapUrl: "https://maps.app.goo.gl/ugRxhbamAmJ4wXDz8", hours: "8am - 12am" },
    { name: "Bab Hitta Tla Al Ali", phone: "06 569 9941", mapUrl: "https://maps.app.goo.gl/4GYhRDqCf3ynUc766", hours: "8am - 1am" },
    { name: "Bab Hitta Mecca.St", phone: "06 552 5513", mapUrl: "https://maps.app.goo.gl/NeMW3owNjDQqnstP9", hours: "8am - 12am" },
    { name: "Bab Hitta Jubeiha", phone: "06 535 3598", mapUrl: "https://maps.app.goo.gl/38CGS9kjw2bW9g4j8", hours: "8am - 12am" },
    { name: "Sigma Pharmacy Khalda", phone: "06 535 4001", mapUrl: "https://maps.app.goo.gl/Bh6vJ3VnpwGPSXND6", hours: "8am - 12am" }
  ];

  return (
    <div className="font-sans bg-gray-50 text-gray-800">
      {/* Navigation, sections, and all JSX here (truncated for brevity) */}
      <footer className="bg-gray-900 text-white text-center p-4 mt-8">
        &copy; 2025 O.M & Bab Hitta Pharmacy | All rights reserved.
      </footer>
    </div>
  );
}
